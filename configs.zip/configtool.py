import configparser
import os.path
# import pprint
# import collections
# from pexpect import popen_spawn
from PyQt5.QtGui import QGuiApplication, QWindow, QIcon, QStandardItemModel
from PyQt5 import QtCore, QtGui, QtWidgets
# from PyQt5.QtCore import pyqtSlot
from PyQt5.QtWidgets import QApplication, QWidget, QInputDialog, QFileDialog, QMainWindow, QGridLayout
from ui import Ui_MainWindow
from datamanip import *


class MainWindow(Ui_MainWindow, QMainWindow):
    def __init__(self, app2):
        Ui_MainWindow.__init__(self)
        self.setupUi(app2)

        def init_data():
            self.configs = []  # collections.OrderedDict()
            self.configboxes = []
            self.configbuttons = []
            self.configdelbuttons = []
            self.csvpaths = []
            self.filedata = {}
            self.defpath = ""
            self.rulepath = ""
            self.sparepath = ""
            self.model = QStandardItemModel()

            self.configboxes = []
            self.configbuttons = []
            self.configdelbuttons = []
            self.configgrids = []

            self.filedict = {}
            self.defaultdef = "C:\\Users\\212564296\\Documents\\ConfigTool\\PythonConfigTool\\defs"
            self.defaultcfg = "C:\\Users\\212564296\\Documents\\ConfigTool\\PythonConfigTool\\configs"

        init_data()
        self.add_events()
        self.add_config_control_row(0)

    def debugme(self):
        print("Configs       : ", len(self.configs))
        print("Config Buttons: ", len(self.configbuttons))
        print("Remove Buttons: ", len(self.configdelbuttons))
        print("Config Boxes  : ", len(self.configboxes))

    #  Connects click detection method to buttons
    def add_events(self):
        self.defbutton.clicked.connect(self.on_click)
        self.rulebutton.clicked.connect(self.on_click)
        self.sparebutton.clicked.connect(self.on_click)

    def on_click(self):
        def askfilename():
            fpath = QFileDialog.getOpenFileName(self)  # Open file picker
            file = list(fpath[0])  # Save file paths
            print(fpath[0])
            return file

        def askfilenames():
            index = self.configbuttons.index(self.sender())  # Get index of pushed button
            print("configbutton: ", index)
            fpaths = QFileDialog.getOpenFileNames(self)  # Open file picker
            files = list(fpaths[0])  # Save file paths
            print(fpaths[0])
            return files

        print("on_click()", end=" ")

        if self.sender() in self.configbuttons:
            load_index = self.configbuttons.index(self.sender())
            print("configbutton[" + load_index + "]")
            if load_index == len(self.configsbuttons):
                filenames = askfilenames()
                print(*filenames, sep="\n")
                for f in filenames:
                    self.add_config(load_index, f)
            else:
                filename = askfilename()
                self.add_config(load_index, filename)
        elif self.sender() in self.configdelbuttons:
            filename = ""
            del_index = self.configdelbuttons.index(self.sender())
            print("configdelbutton[" + del_index + "]")
            self.remove_config(del_index)

        # elif self.sender() == self.defbutton:
        #     self.defbox.setText(askfilename())
        # elif self.sender() == self.rulebutton:
        #     self.rulebox.setText(askfilename())
        # elif self.sender() == self.sparebutton:
        #     self.sparebox.setText(askfilename())
        else:
            print("No button")  # self.debugme()

        self.saveformpaths()

    def add_config_control_row(self, index):
        print("add_config_control_row: ", index)
        hlayout = QtWidgets.QHBoxLayout()
        hlayout.setObjectName("hlayout" + str(index))

        configbutton = QtWidgets.QPushButton(self.verticalLayoutWidget)
        configdelbutton = QtWidgets.QPushButton(self.verticalLayoutWidget)
        configbox = QtWidgets.QLineEdit(self.verticalLayoutWidget)

        configbox.setObjectName("configbox" + str(index))
        configbutton.setObjectName("config" + str(index))
        configbutton.setText("Load Config")
        configdelbutton.setObjectName("configdelbutton" + str(index))
        configdelbutton.setText("X")

        hlayout.addWidget(configbutton)
        hlayout.addWidget(configdelbutton)

        self.formLayout_dynamic.setLayout(index, QtWidgets.QFormLayout.LabelRole, hlayout)
        self.formLayout_dynamic.setWidget(index, QtWidgets.QFormLayout.FieldRole, configbox)
        self.verticalLayout.addLayout(self.formLayout_dynamic)

        # Add to lists
        self.configbuttons.append(configbutton)  # Test for existance first, same for below
        self.configboxes.append(configbox)
        self.configdelbuttons.append(configdelbutton)

        # Connect click methods
        configbutton.clicked.connect(self.on_click)
        configdelbutton.clicked.connect(self.on_click)

    #  Runs when button to load new config is clicked
    def add_config(self, index, filename):
        print("add_config: ", index)
        self.add_config_control_row(len(self.configs)+1)  # +1 might be unnessecy
        print("Added: ", filename, "\nto index ", index)

        def edit_controls():
            print(self.configboxes)
            print(index, len(self.configs), len(self.configboxes))
            self.configboxes[index].setText(filename)

            for i, delbox in enumerate(self.configdelbuttons):
                if i == index:
                    delbox.setEnabled(False)
                else:
                    delbox.setEnabled(True)

        def parse_data():
            print("Controls added/updated.")
            print("Decompiling binary...")
            self.ex()
            print("Reading plain-text configs...")
            for f in self.configs:
                f = f[:-3]+"csv"
                parser = configparser.ConfigParser(inline_comment_prefixes='#')
                name = str(os.path.basename(f))
                print(name)
                print("LOADING: ", f)
                try:
                    self.filedata[name] = parser.read(f)
                except Exception as ex:
                    print(ex)
                # self.filedata[os.path.basename(f)] = self.open_config(f)
                print("LOADED: ", f)
            print("Done.")

        edit_controls()

    def remove_config(self, index):
        print("Removing: ", index)
        self.configboxes[index].deleteLater()
        self.configbuttons[index].deleteLater()
        self.configdelbuttons[index].deleteLater()
        self.configgrids[index].deleteLater()
        if index == 0:
            self.configs = self.configs[1:]
        else:
            self.configs = self.configs[:index-1]+self.configs[index:]
        del self.configboxes[index]
        del self.configbuttons[index]
        del self.configdelbuttons[index]
        del self.configgrids[index]

    def savepaths(self):
        self.defpath = self.defbox.text()
        self.rulepath = self.rulebox.text()
        self.sparepath = self.sparebox.text()
        self.configpaths = self.configs

    # def import_csv(self, filename):
    #     values, headers = [], []
    #     with open(filename, "rb") as fileInput:
    #         print("opening: ", filename)
    #         i = 0
    #         reader = csv.reader(fileInput)
    #         for rows in reader:
    #             print(rows)
    #             print(i, end=" ")
    #             i += 1
    #             if rows:
    #                 rows = rows.split(":")
    #             if len(rows) == 2:
    #                 headers.append(rows[0].strip())
    #                 values.append(rows[1].strip())
    #     return dict(zip(headers, values))

    # # Run the option tool executable with the supplied definitions
    # def ex(self, command="win32opttool.exe"):
    #     try:
    #         # Run the interactive shell
    #         print(command + ' {0}'.format(self.defpath))
    #         child = pexpect.popen_spawn.PopenSpawn(command + ' {0}'.format(self.defpath))
    #         print("!!")
    #     except FileNotFoundError as fnfe:
    #         print(fnfe)
    #         # Ask for new file if the program can't find the executable
    #         # command = askopenfilename(filetype=[("Executables", "*.exe")])
    #         # Run again
    #         # self.ex(command)
    #     else:
    #         print(*self.configs, sep="\n")
    #         for item in self.configs:
    #             print("Interacting with shell...")
    #             print(item)
    #             # Wait for prompt
    #             child.expect(">")
    #             child.sendline("READ {}".format(item))
    #             # Read a new config
    #             print("READ")
    #             child.expect(">")
    #             # Export to plaintext file
    #             child.sendline("WRITEINI {}".format(item[0:-3] + "csv"))
    #             print("WRITE")
    #         # Last prompt
    #         child.expect(">")
    #         # Exit
    #         child.sendline("BYE")
    #         print("Executable completed successfully!")

    # def compare(self, dicts):
    #     d = self.mergedata(dicts)
    #     pprint.pprint(d)
    #     samsies = {}
    #     diffs = {}
    #
    #     for key, val in d:
    #         temp = ""
    #         for item in val:
    #             same = True
    #             if temp == item:
    #                 samsies[key] = val
    #             else:
    #                 diffs[key] = val
    #             temp = item
    #
    #     sim_dict = dicts[0].copy()
    #     for some_dict in dicts:
    #         temp_dict.update(some_dict)
    #     return temp_dict.keys()

        # for file in self.filedata:
        #     for key, value in file:
        #         pass

    def saveformpaths(self):
        # for i, configbox in enumerate(self.configboxes):
        #     self.configs[i] = configbox.text()
        self.configs = [configbox.text() for configbox in self.configboxes]
        self.defpath = self.defbox.text()
        self.sparepath = self.sparebox.text()
        self.rulepath = self.rulebox.text()


def main():
    app = QtWidgets.QApplication(sys.argv)
    app1 = QtWidgets.QMainWindow()
    app1.show()
    prog = MainWindow(app1)  # app)
    sys.exit(app.exec_())

if __name__ == '__main__':
    pass
    # main()

    # def addb():
    #     # self.savepaths()
    #     # print(*self.configs, sep='\n')
    #     if len(files) > 1:
    #         self.configs[index] = files[0]
    #
    #         self.configs.append(files[1:])
    #     else:
    #         self.configs.append(files)
    #
    #     for i, f in enumerate(self.configs):
    #         # print("Adding ", f, "\n", type(f), len(f), type(self.configs), len(self.configs))
    #         if i == 0:
    #             self.add_config(index, f)
    #         else:
    #             self.add_config(len(self.configs), f)