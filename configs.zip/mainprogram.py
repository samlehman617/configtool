import os.path
from PyQt5.QtGui import QStandardItemModel, QColor, QFont
from PyQt5.QtWidgets import QFileDialog, QMainWindow, QTableWidgetItem, QApplication, QPushButton, QLineEdit
from PyQt5.QtWidgets import QSizePolicy, QFormLayout, QHBoxLayout, QMessageBox, QTextEdit, QTabWidget, QHeaderView
from PyQt5.QtCore import QSize, Qt
from ui import UiMainWindow
from datamanip import *
import sys


class MainWindow(UiMainWindow, QMainWindow):
    def __init__(self, app2):
        self.filters = ['Option Definitions (*.def)',
                        'Spare Locations (*.spares)',
                        'Rules (*.rule)',
                        'Config Files (*.cfg *.ini)',
                        'Comma Separated Values (*.csv)',
                        'Excel Spreadsheet (*.xlsx)']

        print("Initializing...")
        UiMainWindow.__init__(self)
        self.setup_ui(app2)

        self.configs = []  # collections.OrderedDict()
        self.configboxes = []
        self.configbuttons = []
        self.configdelbuttons = []
        self.configgrids = []
        self.csvpaths = []
        self.filedata = {}
        self.sames = {}
        self.diffs = {}
        self.same_count = 0
        self.diff_count = 0
        self.defpath = ""
        self.rulepath = ""
        self.sparepath = ""
        self.model = QStandardItemModel()

        self.configboxes = []
        self.configbuttons = []
        self.configdelbuttons = []
        self.configgrids = []

        self.filedict = {}
        self.defaultdef = "C:\\Users\\212564296\\Documents\\ConfigTool\\PythonConfigTool\\defs"
        self.defaultcfg = "C:\\Users\\212564296\\Documents\\ConfigTool\\PythonConfigTool\\configs"

        self.aboutcode = '''
Written in Python (3.5)
Using PyQt5 for GUI.  
Runs (using popen and pexpect) John White's ConfigTool program shell "opttool.exe" to generate files.
'''
        self.aboutusage = '''This is a tool to compute the differences and commonalities between multiple locomotive configuration files.
        
Option, rule, and spare definitions files are stored in a standard configuration format (not to be confused with a locomotive config.)
   
        
Definitions files (.def) describe the names of the options and their corresponding values

Rule files (.rule) describe a list of rules to warn the user if any locomotive configuration violates.  (Not yet implemented)

Spare files (.spare) describe a list of empty bits on a locomotive configuration.  They are an implementation used to supplement the fact that a configuration may have options that revert to a default value, unbeknownst to the user.  This file names the options that cause defaulting to occur.
     
        
Files need not abide by the specific file type, but the tool restricts input files to their respective file type.

If you wish to use a file with an unlisted extension, simply rename it.


See example "C:/Program Files/ConfigCompare/rules/example.rule" for examples on the syntax of .rule and .spare files.
'''

        self.bold = [[]]
        self.spare = [[]]
        # QHeaderView().clicked()
        # samehheaders = self.sametable.horizontalHeader()
        # diffhheaders = self.difftable.horizontalHeader()
        # samehheaders.setClickable(True)
        # diffhheaders.setClickable(True)
        print("Adding event handlers...")
        self.defbutton.clicked.connect(self.on_click)
        # self.rulebutton.clicked.connect(self.on_click)
        self.sparebutton.clicked.connect(self.on_click)
        self.addconfigbutton.clicked.connect(self.on_click)
        self.actionAbout.triggered.connect(self.on_menu_click)
        self.menuClear.triggered.connect(self.clear)
        self.actionSave_Comparison_As.triggered.connect(self.on_save_menu)
        # samehheaders.clicked.connect(self.onSectionClicked)
        # diffhheaders.clicked.connect(self.onSectionClicked)
        # self.tabwidget.currentChanged.connect(self.run_me)
        # self.tabwidget.currentChanged(1).connect(self.run_me)
        # self.tabwidget.currentChanged(2).connect(self.run_me)
        # self.difftab.clicked.connect(self.run_me)
        print("Initialized.")

    # Defines the behavior for when a button is clicked (adding files)
    def on_click(self):
        print("on_click()")
        try:
            if self.sender() == self.addconfigbutton:
                print("Found sender")
                newpaths = self.askfilenames()
                print("Assigned path")
                for path in newpaths:
                    print("Path")
                    if path != "":
                        print("Path found")
                        self.add_config(path)
            elif self.sender() == self.defbutton:
                # print("Found sender")
                path = self.askfilename(0)
                # print("Path assigned")
                self.defbox.setText(path)
            elif self.sender() == self.sparebutton:
                path = self.askfilename(1)
                self.sparebox.setText(path)
            # elif self.sender() == self.rulebutton:
            #     path = self.askfilename(2)
            #     self.rulebox.setText(path)

            if (self.defpath != "") & (len(self.configs) >= 1):
                # print("Running...")
                self.run_me()
        except Exception as exc:
            print("Error", exc)

    # Defines behavior for clicking edit button for individual config.
    def on_edit_click(self):
        print("on_edit_click")
        try:
            edit_index = self.configbuttons.index(self.sender())
            path = self.askfilename(3)
            self.edit_config(edit_index, path)
            if len(self.configs) > 0:
                self.run_me()
        except Exception as expt:
            print(expt)

    # defines behavior for clicking remove button for individual config.
    def on_del_click(self):
        print("on_del_click()")
        try:
            del_index = self.configdelbuttons.index(self.sender())
            self.remove_config(del_index)
        except Exception as delexc:
            print(delexc)

    # Defines behavior for about menu
    def on_menu_click(self):
        self.msg = QMessageBox()
        self.msg.setIcon(QMessageBox.Information)
        self.msg.setText("Author: Sam Lehman")
        self.msg.setDetailedText(self.aboutusage)
        self.msg.setWindowTitle("About Config Compare")
        self.msg.setInformativeText(self.aboutcode)
        self.msg.setStandardButtons(QMessageBox.Ok)
        self.msg.setFixedHeight(600)
        self.msg.show()

    def on_save_menu(self):
        try:

            file = self.askfilename(5)
            print("saving...")
            diffs = self.savedict(self.difftable)
            print("saving...")
            sames = self.savedict(self.sametable)
            print("exporting...")
            heads = [os.path.basename(cfg) for cfg in self.configs]
            self.export_xl(file, diffs, sames, heads)
            print("done :)")
        except Exception as xp_exc:
            print(xp_exc)
    # When the table is sorted
    # def onSectionClicked(self):
    #     print("sort")
    #     self.same_count = len(self.sames)
    #     self.diff_count = len(self.diffs)
    #     # print("Setting status...")
    #     self.statusbar.showMessage("Diffs: " + str(self.diff_count) + " Sims: " + str(self.same_count))
    #     # Populate both tables with diffs, sims ...respectively
    #     hheaders = self.difftable.horizontalHeader()
    #
    #     try:  # Highlight the values that match up with spare options
    #         self.populate_grid(self.diffs, self.difftable)
    #         self.populate_grid(self.sames, self.sametable)
    #         self.highlight_spares()
    #         # self.display_configs()
    #         # Add rule matching
    #         # Add counting least common values
    #     except Exception as Ex:
    #         print("Couldn't highlight spares.")
    #         print(Ex)  # Otherwise print any error that occurs

    # Saves the fields from the form and pushes them into class's member data
    def saveformtext(self):
        # print("Saving paths from form...")
        self.configs = []
        for configbox in self.configboxes:
            if configbox.text() != "":
                self.configs.append(configbox.text())

        # self.configs = [configbox.text() for configbox in self.configboxes if configbox.text() != ""]
        self.defpath = self.defbox.text()
        self.sparepath = self.sparebox.text()
        # self.rulepath = self.rulebox.text()

    def savedict(self, element):
        dict1 = {}
        try:
            rows = element.rowCount()
            cols = element.columnCount()
            for i in range(0, rows):
                dict1[element.item(i, 0).text()] = []
                for j in range(0, cols):
                    dict1[element.item(i, 0).text()].append(element.item(i, j).text())
            self.datadict = dict1

        except Exception as savedictexcp:
            print(savedictexcp)
        else:
            return dict1

    # Adds new row of widgets for a config
    def add_config_widgets(self, path):
        print("add_config_widgets(" + str(len(self.configs)) + ")")
        # self.debug()
        hlayout = QHBoxLayout()
        hlayout.setObjectName("hlayout" + str(len(self.configs)))
        hlayout.setSpacing(1)
        # Declare new widgets
        configbutton = QPushButton(self.loadtab)
        configdelbutton = QPushButton(self.loadtab)
        configbox = QLineEdit(self.loadtab)
        # Connect click methods
        configbutton.clicked.connect(self.on_edit_click)
        configdelbutton.clicked.connect(self.on_del_click)
        # Add to lists
        self.configbuttons.append(configbutton)  # Test for existance first, same for below
        self.configboxes.append(configbox)
        self.configdelbuttons.append(configdelbutton)
        self.configgrids.append(hlayout)

        size_policy = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Minimum)
        size_policy.setHorizontalStretch(0)
        size_policy.setVerticalStretch(0)
        size_policy.setHeightForWidth(configbox.sizePolicy().hasHeightForWidth())
        configbox.setObjectName("configbox" + str(len(self.configs)))
        configbox.setText(path)  # str(len(self.configs)) + "  " + path)
        configbox.setReadOnly(True)
        configbox.setMinimumSize(QSize(50, 25))
        configbox.setMaximumWidth(700)
        configbox.setAlignment(Qt.AlignCenter)
        # configbox.setFixedHeight(40)

        configbutton.setObjectName("config" + str(len(self.configs)))
        configbutton.setText("Edit Config")  # + str(len(self.configs)))
        configbutton.setFixedWidth(80)
        configbutton.setMinimumSize(QSize(96, 25))
        configdelbutton.setObjectName("configdelbutton" + str(len(self.configs)))
        configdelbutton.setText("X")  # str(len(self.configs)))
        configdelbutton.setFixedWidth(30)
        configdelbutton.setMinimumSize(QSize(10, 25))

        hlayout.addWidget(configbutton)
        hlayout.addWidget(configdelbutton)
        print(len(self.configs))
        self.debug()
        self.formLayout_dynamic.setLayout(len(self.configs), QFormLayout.LabelRole, hlayout)
        self.formLayout_dynamic.setWidget(len(self.configs), QFormLayout.FieldRole, configbox)

    # Adds a new config
    def add_config(self, path):
        print("Adding config...")
        self.configs.append(path)
        self.add_config_widgets(path)
        self.saveformtext()
        self.run_me()

        # self.filedata[os.path.basename(path)] = import_csv(path)

    # Edits and existing config
    def edit_config(self, index, path):
        print("Editing config[" + str(index) + "] in row " + str(index))
        self.configboxes[index].setText(path)
        self.saveformtext()
        self.run_me()

    # Removes an existing config
    def remove_config(self, index):
        print("Removing config...")
        try:
            self.configboxes[index].deleteLater()
            self.configbuttons[index].deleteLater()
            self.configdelbuttons[index].deleteLater()
            self.configgrids[index].deleteLater()

            del self.configboxes[index]
            del self.configbuttons[index]
            del self.configdelbuttons[index]
            del self.configgrids[index]
            self.saveformtext()
            try:
                print(str(*self.formLayout_dynamic.findChildren(QLineEdit)))
                print(str(*self.formLayout_dynamic.findChildren(QPushButton)))
                self.debug()
            except Exception as err:
                print(err)
            print("saveform")
            if len(self.configs) >= 0:
                self.run_me()
        except Exception as excpe:
            print(excpe)
        finally:
            self.run_me()

    # Query's the user for a filename(s)
    def askfilename(self, index=0):
        dialog = QFileDialog(self)
        # dialog.setNameFilters(self.filters)
        if self.filters[index]:
            # print("Testing filters")
            try:  # Try to filter the input by filetype, but allow a coverall
                dialog.setNameFilter(self.filters[index])
            except Exception as filterErr:
                dialog.setNameFilters(self.filters)
            print(self.filters[index])
        dialog.exec_()
        path = dialog.selectedFiles()
        if len(path) == 1:
            path = path[0]
        else:
            path = ""
        # print(dialog.selectedFiles()[0])
        if path == "" or path == [] or path is None:
            print("No file")
            return ""
            # raise FileNotFoundError
        else:
            return dialog.selectedFiles()[0]

    def askfilenames(self):
        dialog = QFileDialog(self)
        dialog.setFileMode(QFileDialog.ExistingFiles)
        # dialog.setNameFilters(self.filters)
        if self.filters[3]:
            # print("Testing filters")
            try:  # Try to filter the input by filetype, but allow a coverall
                dialog.setNameFilter(self.filters[3])
            except Exception as filterErr:
                dialog.setNameFilters(self.filters)
            # print(self.filters[3])
        dialog.exec_()

        path = dialog.selectedFiles()
        if len(path) == 1:
            path = path[0]
        elif len(path) < 1:
            path = ""
        else:
            pass
        # print(dialog.selectedFiles()[0])
        if path == "" or path == [] or path is None:
            print("No file")
            return ""
            # raise FileNotFoundError
        else:
            return dialog.selectedFiles()

        # return list(QFileDialog.getOpenFileNames(self)[0])  # Open file picker

    # Print some useful information
    def debug(self):
        print("Configs:", len(self.configs), [os.path.basename(config) for config in self.configs])
        print("Config Edit Buttons:", len(self.configbuttons))
        print("Config Del Buttons:", len(self.configdelbuttons))
        print("Config Boxes:", len(self.configboxes))

    def clear(self):
        self.statusbar.showMessage("")
        for i in range(0, len(self.configs)):
            self.remove_config(i)
        self.configs = []
        self.configdelbuttons = []
        self.configbuttons = []
        self.configboxes = []
        self.configgrids = []
        self.defpath = ""
        self.sparepath = ""
        self.sparebox.setText("")
        self.defbox.setText("")

    # Run the analysis
    def run_me(self):

        print("run_me()")
        # Use hardcoded configs if none provided (so I don't have to load them every time to debug this thing)
        if len(self.configs) == 0:
            self.configs = ["C://Users//212564296//Documents//ConfigTool//PythonConfigTool//configs//CFG00532.CFG",
                            "C://Users//212564296//Documents//ConfigTool//PythonConfigTool//configs//CFG01623.CFG",
                            "C://Users//212564296//Documents//ConfigTool//PythonConfigTool//configs//CFG01717.CFG"]
        # Use default definition if none provided
        if self.defpath == "":
            self.sames, self.diffs = run_analysis(self.configs)
        else:
            self.sames, self.diffs = run_analysis(self.configs, self.defpath)
        # print("Diffs", len(self.diffs))
        # print("Sames:", len(self.sames))

        self.same_count = len(self.sames)
        self.diff_count = len(self.diffs)
        # print("Setting status...")
        self.statusbar.showMessage("Diffs: " + str(self.diff_count) + " Sims: " + str(self.same_count))
        # Populate both tables with diffs, sims ...respectively

        try:  # Highlight the values that match up with spare options
            self.populate_grid(self.diffs, self.difftable)
            self.populate_grid(self.sames, self.sametable)
            print("highlight_spares()")
            self.highlight_spares()
            # self.display_configs()
            # Add rule matching
            # Add counting least common values
        except Exception as Ex:
            print("Couldn't highlight spares.")
            print(Ex)  # Otherwise print any error that occurs

    # Method to place data in the grid of element
    def populate_grid(self, data, element):
        # print(data)
        # print("Populating", element.objectName() + "...")

        # Full path -> Filename ...to place in top header
        hheaders = ["Options:"] + [os.path.basename(cfg) for cfg in self.configs]
        # vheaders = [key.upper() for key in data.keys()]  # ...get option names to put in left headers
        # Define dimensions for grid
        element.setRowCount(len(data.items()))
        element.setColumnCount(len(self.configs)+1)
        # Actually place headers now
        element.setHorizontalHeaderLabels(hheaders)
        # element.setVerticalHeaderLabels(vheaders)

        print(element.objectName()+": Grid size set = (" + str(len(data.items())) + ", " + str(len(self.configs)) + ")")
        # for i, (k, v) in enumerate(data.iteritems()):
        # element.setItem(0, 0, QTableWidgetItem("Option:"))
        # print(self.configs)
        # print(str(0), "Option:")
        # for c, cfg in enumerate(self.configs):
        #     # print(c+1, os.path.basename(cfg))
        #     element.setItem(0, c+1, QTableWidgetItem(os.path.basename(cfg)))
        # print("Set headers.")

        # Go through all rows

        for i, (key, value) in enumerate(data.items()):
            print(i, key)
            # Set option
            element.setItem(i, 0, QTableWidgetItem(str(key).upper()))
            # Set all vals in row
            for j, val in enumerate(data[key]):
                element.setItem(i, j+1, QTableWidgetItem(val))

        # for i, k, v in enumerate(zip(data.keys(), data.values())):
        #     print(k, v)
        #     for j, col in enumerate(v):
        #         item = QTableWidgetItem(col)
        #         element.setItem(i, j, item)
    # Load the configuration file that defines where spares are
    def load_spares(self):
        self.sparepath = self.sparebox.text()
        with open(self.sparepath, "r") as sp:
            parse_spares(sp)

    # Apply formatting for spares
    def highlight_spares(self):

        def find(element):
            print("find")
            print(element)
            self.bold = [[0*x*y for x in range(1, element.columnCount())] for y in range(1, element.rowCount())]
            self.spare = [[0*x*y for x in range(1, element.columnCount())] for y in range(1, element.rowCount())]
            print(self.bold)
            for row in range(0, element.rowCount()-1):
                counts = {}
                for col in range(1, element.columnCount()):
                    if element.item(row, col).text() not in counts.keys():
                        print("testing...")
                        counts[element.item(row, col).text()] = 0
                    counts[element.item(row, col).text()] += 1  # element.currentRow().__dict__()
                print("counted row")
                if element.item(row, 0).text() in spares:
                    found_ind = spares.index(element.item(row, 0).text())
                    print("found", element.item(row, 0).text(), "in spares")
                    for col in range(1, element.columnCount()):
                        element.item(row, col).setBackground(QColor(255, 150, 155))  # .element.currentRow()
                        if element.item(row, col).text() == defaults[found_ind]:
                            element.item(row, col).setBackground(QColor(200, 125, 65))
                            self.spare[row-1][col-1] = 2
                minval = min(counts, key=counts.get)
                print("found_min")
                for col in range(1, element.columnCount()):
                    font = QFont()
                    font.setBold(True)
                    self.bold[row-1][col-1] = 0
                    if element.item(row, col).text() == minval:
                        print(row, col, minval)
                        self.bold[row-1][col-1] = 3
                        element.item(row, col).setFont(font)
                    else:
                        self.bold[row-1][col-1] = 2

            print("Highlighted.")
        try:
            spares, defaults = parse_spares(self.sparepath)
            find(self.difftable)
            find(self.sametable)
        except Exception as SpareReadErr:
            print("SPARE:", SpareReadErr)

    # Apply formatting for lcv
    def highlight_least_common_value(self):
        pass

    # Apply highlighting for rule violations
    def highlight_rule_violations(self):
        pass

    def display_configs(self):
        print("!")
        configtabs = QTabWidget(self.tabwidget)
        self.tabwidget.addTab("Configs", self)
        for config in self.configs:
            configtempview = QTextEdit()
            self.configtabs.addTab(configtempview, os.path.basename(config))
            with open(config, "r") as cfg:
                configtempview.setText(cfg.read())

    def export_xl(self, filepath, diffs, sames, fileheaders):

        def worksheet(shtname, data):
            work_sheet = workbook.add_worksheet(shtname)
            row = 0
            col = 1
            for i, item in enumerate(["Options:"] + fileheaders):
                work_sheet.write(0, i, item)
            print(data)
            for key, vals in data.items():
                work_sheet.write(row+1, 0, key)
                for val in vals[1:]:
                    print("("+str(row)+", "+str(col)+")")
                    forma = workbook.add_format()
                    forma.set_bold(False)
                    forma.set_bg_color("white")
                    if self.bold[row][col-1] == 3:
                        print("("+str(row)+str(col)+str(self.bold[row][col])+")", end=" ")
                        forma.set_bold(True)
                    if self.spare[row][col-1] == 2:
                        forma.set_bg_color("orange")
                    work_sheet.write(row + 1, col, val, forma)
                    col += 1

                row += 1
                col = 1

        try:
            print("export_xl()")
            print(self.bold)
            print(self.spare)
            workbook = xlsxwriter.Workbook(filepath[:-3] + ".xlsx")
            worksheet("Diffs", diffs)
            worksheet("Same", sames)
            workbook.close()
        except IndexError as ie:
            print(ie)


def main():
    app = QApplication(sys.argv)
    app1 = QMainWindow()
    app1.show()
    prog = MainWindow(app1)  # app)
    sys.exit(app.exec_())

if __name__ == '__main__':
    import sys
    main()
