import configparser
from pexpect import popen_spawn
from PyQt5.QtWidgets import QFileDialog as FileDialog
import csv
import os
import xlsxwriter


# Imports the configuration file (not CSV actually.  Will fix later)
def import_csv(filename):
    print("import_csv(" + filename + ")")

    # Create configparser obj with custom preferences
    parser = configparser.SafeConfigParser(inline_comment_prefixes=("#",),
                                           comment_prefixes=('#', ';'),
                                           delimiters=(":",),
                                           allow_no_value=False,
                                           strict=False
                                           )
    # print("Parser reading...")
    try:  # Try everything...well, maybe just a few common file encodings
        parser.read(filename, encoding="utf-8")
    except configparser.Error as err:
        try:
            parser.read(filename, encoding="ANSI")
        except configparser.Error as err1:
            try:
                parser.read(filename, encoding="utf_8")
            except configparser.Error as err2:
                print(err2)
            print(err1)
        print(err)
    # Reshape data into dictionary
    # print("Parser generating...")
    outp = parsertodict(parser)
    print("parsed", filename)
    return outp





# Cheange the extension of files
# *** assumes the original file has a 3 char filetype ***
def change_ext(fpath):
    print("change_ext("+fpath+")")
    base = str(fpath)[0:-3]
    spread = str(base) + "csv"
    # print("New:", spread)
    return spread


# Merge dictionary values under same key (but in different dicts)
def combine_dict_val(*args):
    print("combine_dict_val("+args+")")
    result = {}
    for dic in args:
        for key in (result.viewkeys() | dic.keys()):
            if key in dic:
                result.setdefault(key, []).append(dic[key])
    return result


# Run the option tool executable with the supplied definitions
def ex(configs,
       defpath="C://Users//212564296//Documents//ConfigTool//PythonConfigTool//defs//s.dclocopt.def",
       command="win32opttool.exe"):
    print("ex("+defpath+", "+command)
    try:
        # Run the interactive shell
        print(command + ' {0}'.format(defpath))
        child = popen_spawn.PopenSpawn(command + ' {0}'.format(defpath))
    except FileNotFoundError as fnfe:
        try:
            command = os.path.abspath(command)
            print(command + ' {0}'.format(defpath))
            child = popen_spawn.PopenSpawn(command + ' {0}'.format(defpath))
        except FileNotFoundError as fnfe2:
            try:
                command = "C://Program Files//Config Compare//win32opttool.exe"
                print(command + ' {0}'.format(defpath))
                child = popen_spawn.PopenSpawn(command + ' {0}'.format(defpath))
            except FileNotFoundError as fnfe3:
                print(command + ' {0}'.format(defpath))
                child = popen_spawn.PopenSpawn(command + ' {0}'.format(defpath))
            else:
                dialog = FileDialog()
                command = FileDialog.getOpenFileName(dialog)[0]
                if command == "":
                    return
                print(command)
                ex(configs, defpath, command)
                print(fnfe)
    else:
        for item in configs:
            print("Interacting with shell...", item)
            # print(item)
            # Wait for prompt
            child.expect(">")
            child.sendline("READ {}".format(item))
            # Read a new config
            # print("READ", item)
            child.expect(">")
            # Export to plaintext file
            child.sendline("WRITEINI {}".format(item[0:-3] + "csv"))
            # print("WRITE")
        # Last prompt
        child.expect(">")
        # Exit
        child.sendline("BYE")
        print("Executable completed successfully!")




# Grab the data
def get_data(configs):
    print("get_data(configs)")  # "+configs+")")
    # print("Changing extensions for", len(configs), "items...")
    # print(*configs, sep="\n")
    configs_csv = []
    data = []
    for cfg in configs:
        if len(cfg) > 4:
            new = change_ext(cfg)
            # print("New:", new)
            configs_csv.append(new)
    # configs_csv = [change_ext(f) for f in configs if len(f) > 4]
    # print(*configs_csv, sep="\n")
    #
    # print("Retrieved data.")
    # print(*configs_csv, sep="\n")
    for sheet in configs_csv:
        data.append(import_csv(sheet))
    #
    # data = [import_csv(sheet) for sheet in configs_csv]
    # print("Parsed all configs")
    return data


# Compare many dicts
def compare(in_data):
    print("compare(in_data)")  # +in_data+")")
    # print("Generating comparison...")
    # print(*in_data, sep="\n")
    # print("DONE")

    def check_equal(lst):
        return len(set(lst)) == 1

    # print(in_data)
    # print("done")
    sames, diffs = {}, {}

    # keys = in_data.keys()
    # vals = in_data.values()
    # print(keys)
    # print(vals)
    # for {k : v} in in_data:
    #     print(k, ":", v)
    try:
        for key, values in in_data.items():
            # print("hi")
            # print(key)
            if check_equal(values):
                # print("values equal")
                if key in sames:
                    sames[key].append(values)
                else:
                    sames[key] = values
            else:
                # print("values not equal")
                if key in sames:
                    diffs[key].append(values)
                else:
                    diffs[key] = values
    except Exception as compareErr:
        print("CompareErr:", compareErr)

    finally:
        print(sames)
        print(diffs)

        return sames, diffs


# Read list of dicts
def dictlist(dicts):
    print("dictlist(dicts)")  # "+dicts+")")
    try:
        return {k: [d[k] for d in dicts] for k in dicts[0]}
    except Exception as DictError:
        print(DictError)
        return None


# Read from config files
def parse_spares(f):
    print("parse_spares("+f+")")
    parser = configparser.SafeConfigParser(inline_comment_prefixes=("#",),
                                          comment_prefixes=('#', ';'),
                                          delimiters=(":",),
                                          allow_no_value=False,
                                          strict=False
                                          )
    print("Parser created (Spares)")

    try:
        parser.read(f, encoding="utf-8")
    except configparser.Error as err:
        try:
            parser.read(f, encoding="ANSI")
        except configparser.Error as err1:
            try:
                parser.read(f, encoding="utf_8")
            except configparser.Error as err2:
                print(err2)
            print(err1)
        print(err)
    outp = parsertodict(parser)

    spares = list([key.upper() for key in outp.keys()])
    defaults = list([val.upper() for val in outp.values()])

    return spares, defaults


# Create dictionary from configparser
def parsertodict(parser):
    print("parsertodict(parser)")  # +parser+")")
    mydict = {}
    for section_name in parser:
        section = parser[section_name]
        for name in section:
            mydict[name] = section[name]
    return mydict


# Wrapper for the steps needed to analyze data
def run_analysis(configs, defpath="C://Users//212564296//Documents//ConfigTool//PythonConfigTool//defs//s.dclocopt.def"):
    print("run_analysis(configs, "+defpath+")")
    ex(configs, defpath)
    csv_data = get_data(configs)
    dict_data = dictlist(csv_data)  # combine_dict_val(csv_data)  # mergedata(csv_data)
    # print("Merged dictionaries.")
    return compare(dict_data)

# def write_csv(filename):
#     with open(filename, "wb") as file_output:
#         writer = csv.writer(file_output)
#         for row_number in range(self.model.rowCount()):
#             fields = [
#                 self.model.data(
#                     self.model.index(row_number, column_number),
#                     QtCore.Qt.DisplayRole
#                 )
#                 for column_number in range(self.model.columnCount())
#             ]
#             writer.writerow(fields)
