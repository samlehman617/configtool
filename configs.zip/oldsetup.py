from distutils.core import setup
import py2exe

setup(windows=['mainprogram.py'],
      options={"py2exe": {"packages": ["os", "pexpect", "configparser", "PyQt5"]}})


# import sys
# from cx_Freeze import setup, Executable
#
# build_exe_options = {"packages": ["os", "csv", "pexpect", "PyQt5", "configparser"],
#                      "excludes": ["tkinter"],
#                      "include_files": ["win32opttool.exe"]}
#
# base = None
#
# if sys.platform == "win32":
#     base = "Win32GUI"
#
# setup(name="Config Comparison Tool",
#       version="0.1",
#       description="A tool to compare multiple locomotive configuration files.",
#       options={"build_exe": build_exe_options},
#       executables=[Executable("mainprogram.py", base=base),
#                    Executable("datamanip.py", base=base),
#                    Executable("ui.py", base=base)])
#
#
# include_files = ["win32opttool.exe"]
#
# zip_includes = ["win32opttool.exe"]
